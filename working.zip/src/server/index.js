import express from "express";
import http from "http";
import { Server } from "socket.io";
import { MongoClient } from "mongodb";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const server = http.createServer(app);

// ✅ Match your frontend origin (Vite runs on 5173 by default)
const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"],
    credentials: true,
  },
});

app.use(cors());
app.use(express.json());

const PORT = Number(process.env.PORT) || 3001;
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017";
const DB_NAME = "RedisTransactions"; // Use your RedisTransactions database
const FRAUD_COLLECTION = "fraud_transactions"; // Fraud transactions collection
const LEGIT_COLLECTION = "legit_transactions"; // Legit transactions collection

// 🔁 Connect to Mongo and start listening
MongoClient.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then((client) => {
    const db = client.db(DB_NAME);
    const fraudCollection = db.collection(FRAUD_COLLECTION);
    const legitCollection = db.collection(LEGIT_COLLECTION);

    console.log("✅ Connected to MongoDB");

    // Change stream to listen for new fraud transactions
    const fraudChangeStream = fraudCollection.watch([], { fullDocument: "updateLookup" });
    fraudChangeStream.on("change", (change) => {
      if (change.operationType === "insert") {
        const txn = change.fullDocument;
        io.emit("new_transaction", txn);
        console.log("📡 New fraud transaction broadcasted:", txn._id);
      }
    });

    // Change stream to listen for new legit transactions
    const legitChangeStream = legitCollection.watch([], { fullDocument: "updateLookup" });
    legitChangeStream.on("change", (change) => {
      if (change.operationType === "insert") {
        const txn = change.fullDocument;
        io.emit("new_transaction", txn);
        console.log("📡 New legit transaction broadcasted:", txn._id);
      }
    });

    // Basic REST endpoint to get recent transactions (both fraud and legit)
    app.get("/api/transactions", async (req, res) => {
      try {
        // Fetch data from both fraud and legit collections
        const fraudTransactions = await fraudCollection
          .find({})
          .sort({ processed_timestamp: -1 })
          .limit(50) // Adjust limit as necessary
          .toArray();

        const legitTransactions = await legitCollection
          .find({})
          .sort({ processed_timestamp: -1 })
          .limit(50) // Adjust limit as necessary
          .toArray();

        // Combine the results
        const transactions = [...fraudTransactions, ...legitTransactions];

        res.json(transactions);
      } catch (err) {
        console.error("❌ Failed to fetch transactions:", err);
        res.status(500).send("Internal Server Error");
      }
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB Connection Error:", err);
    process.exit(1); // Prevent running a broken app
  });

// 🌐 Socket.IO Connection Handler
io.on("connection", (socket) => {
  console.log("🔌 WebSocket client connected:", socket.id);

  socket.on("disconnect", () => {
    console.log("❌ WebSocket client disconnected:", socket.id);
  });
});

// 🚀 Start server
server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
